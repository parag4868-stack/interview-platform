
const apiBase = window.location.origin + '/api';

function el(id){ return document.getElementById(id); }
function show(id){ el(id).classList.remove('hidden'); }
function hide(id){ el(id).classList.add('hidden'); }

el('startBtn').addEventListener('click', async ()=>{
  const name = el('candidateName').value.trim();
  const email = el('candidateEmail').value.trim();
  if(!name || !email){ alert('Enter name and email'); return; }
  const payload = {
    candidateName: name, candidateEmail: email,
    role: el('role').value, level: el('level').value, mode: el('mode').value
  };
  const res = await fetch(apiBase + '/sessions', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const data = await res.json();
  if(!res.ok){ el('message').textContent = 'Failed to start session: ' + (data.message || res.status); return; }
  el('sessionId').textContent = data.id;
  el('sessionArea').classList.remove('hidden');
  el('setup').classList.add('hidden');
  loadQuestion(data.id);
});

el('endBtn').addEventListener('click', async ()=>{
  const id = el('sessionId').textContent;
  await fetch(apiBase + `/sessions/${id}/end`, { method:'POST' });
  location.reload();
});

async function loadQuestion(sessionId){
  const res = await fetch(apiBase + `/sessions/${sessionId}/next`);
  const data = await res.json();
  if(res.ok){
    el('questionText').textContent = data.question;
    el('feedback').innerHTML = '';
  } else {
    el('questionText').textContent = 'No question available';
  }
}

el('submitAnswer').addEventListener('click', async ()=>{
  const id = el('sessionId').textContent;
  const answer = el('answer').value.trim();
  if(!answer){ alert('Write an answer'); return; }
  const res = await fetch(apiBase + `/sessions/${id}/answer`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ answer }) });
  const data = await res.json();
  if(res.ok){
    el('feedback').innerHTML = `<div class="p-3 border rounded"><strong>Feedback:</strong><pre class="whitespace-pre-wrap">${data.feedback}</pre></div>`;
    el('answer').value = '';
    // load next question after a short delay
    setTimeout(()=> loadQuestion(id), 800);
  } else {
    el('feedback').textContent = 'Error: ' + (data.message || res.status);
  }
});

el('skipBtn').addEventListener('click', async ()=>{
  const id = el('sessionId').textContent;
  await fetch(apiBase + `/sessions/${id}/skip`, { method:'POST' });
  loadQuestion(id);
});

el('viewSessions').addEventListener('click', async ()=>{
  const res = await fetch(apiBase + '/sessions');
  const data = await res.json();
  el('list').innerHTML = '';
  data.forEach(s => {
    const li = document.createElement('li');
    li.className = 'p-2 border rounded flex justify-between';
    li.innerHTML = `<div><strong>${s.id}</strong><div class="text-xs text-gray-600">${s.candidateName} • ${s.role} • ${new Date(s.created_at).toLocaleString()}</div></div><div><button data-id="${s.id}" class="openBtn px-2 py-1 border rounded">Open</button></div>`;
    el('list').appendChild(li);
  });
  el('sessionsList').classList.remove('hidden');
  el('setup').classList.add('hidden');
  el('sessionArea').classList.add('hidden');
  el('message').textContent = '';
  document.querySelectorAll('.openBtn').forEach(b=> b.addEventListener('click', ()=>{
    const id = b.getAttribute('data-id');
    // open session: load first question
    fetch(apiBase + `/sessions/${id}`).then(r=>r.json()).then(d=>{
      el('sessionId').textContent = d.id;
      el('sessionArea').classList.remove('hidden');
      el('sessionsList').classList.add('hidden');
    });
    loadQuestion(id);
  }));
});
