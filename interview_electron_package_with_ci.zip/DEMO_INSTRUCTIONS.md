
DEMO VIDEO SCRIPT & RECORDING GUIDE
==================================

Goal: Produce a short (2-4 min) demo video showing how to use the desktop app.

Tools:
- OBS Studio (free) or any screen recorder.
- Electron app built from this package (run `npm run start`).

Recording steps:
1. Start OBS and set up a single 'Window Capture' or 'Display Capture' source capturing the Electron window.
2. Set output to 1280x720, 30 FPS, MP4 or MKV container.
3. Start recording, then perform the following actions while narrating (or add captions later):
   a. Open the app (double-click the EXE or run `npm run start`).
   b. Show the setup screen: enter Candidate Name and Email; choose Role and Level.
   c. Click 'Start Session' — point out that a session ID is created and the first question appears.
   d. Type an answer and click 'Submit Answer' — show how feedback appears.
   e. Skip a question and show the next one.
   f. End the session and show the Sessions list via 'My Sessions' button.
   g. Open a previous session and show stored answers / feedback.
4. Stop recording. Optionally trim start/end in a video editor and add captions.
5. Export MP4 and share.

Suggested narration script (short):
"Hi — this is a quick demo of the Interview Practice desktop app. I'll create a session for a candidate, answer a sample question, and show the automated feedback. First, I enter the candidate name and email, select Backend Engineer mid-level, and start the session. The app generates a session ID and shows the first question. I type my answer and submit — the app evaluates the response and shows feedback. I can skip or end the session anytime. Finally, the 'My Sessions' view shows recorded sessions with timestamps and answers."
