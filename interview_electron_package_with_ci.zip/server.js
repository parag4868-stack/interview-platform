
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const fetch = require('node-fetch');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

const DATA_FILE = path.join(__dirname, 'sessions.json');
function readData(){ try{ return JSON.parse(fs.readFileSync(DATA_FILE)); } catch(e){ return { sessions: [] }; } }
function writeData(d){ fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2)); }

// Simple question banks per role
const QUESTION_BANK = {
  backend: [
    'Design a URL shortening service. Talk about data model and scaling.',
    'Explain how you would design a REST API for a blog platform.',
    'How do you handle database migrations in production?'
  ],
  data: [
    'Explain how you would approach a classification problem with imbalanced data.',
    'Describe A/B testing design and metrics to monitor.',
    'How do you evaluate a regression model?'
  ],
  pm: [
    'How would you prioritise features for a new product?',
    'Describe a time you resolved a conflict with stakeholders.',
    'Walk me through designing an MVP for a mobile app.'
  ],
  finance: [
    'Explain provisions for doubtful debts and their accounting treatment.',
    'How do you perform bank reconciliation?',
    'Explain deferred tax assets and liabilities.'
  ]
};

// Optional OpenAI integration: set OPENAI_API_KEY in env to enable richer feedback
const OPENAI_KEY = process.env.OPENAI_API_KEY || null;

app.get('/api/sessions', (req, res) => {
  const data = readData();
  res.json(data.sessions);
});

app.post('/api/sessions', (req, res) => {
  const body = req.body || {};
  const id = 's_' + Date.now();
  const session = {
    id, created_at: new Date().toISOString(), status: 'active',
    candidateName: body.candidateName || 'Unknown', candidateEmail: body.candidateEmail || '',
    role: body.role || 'backend', level: body.level || 'mid', mode: body.mode || 'text',
    questionIndex: 0, asked: [], answers: []
  };
  const data = readData();
  data.sessions.push(session);
  writeData(data);
  res.json(session);
});

app.get('/api/sessions/:id', (req, res) => {
  const data = readData();
  const s = data.sessions.find(x=>x.id === req.params.id);
  if(!s) return res.status(404).json({ message: 'Not found' });
  res.json(s);
});

app.post('/api/sessions/:id/skip', (req, res) => {
  const data = readData();
  const s = data.sessions.find(x=>x.id === req.params.id);
  if(!s) return res.status(404).json({ message: 'Not found' });
  s.questionIndex = (s.questionIndex || 0) + 1;
  writeData(data);
  res.json({ ok: true });
});

app.get('/api/sessions/:id/next', async (req, res) => {
  const data = readData();
  const s = data.sessions.find(x=>x.id === req.params.id);
  if(!s) return res.status(404).json({ message: 'Not found' });
  const bank = QUESTION_BANK[s.role] || QUESTION_BANK['backend'];
  const idx = s.questionIndex || 0;
  if(idx >= bank.length) return res.status(200).json({ question: 'No more questions. Session complete.' });
  const q = bank[idx];
  // mark asked
  s.asked = s.asked || [];
  s.asked.push({ index: idx, question: q, asked_at: new Date().toISOString() });
  writeData(data);
  res.json({ question: q });
});

app.post('/api/sessions/:id/answer', async (req, res) => {
  const body = req.body || {};
  const data = readData();
  const s = data.sessions.find(x=>x.id === req.params.id);
  if(!s) return res.status(404).json({ message: 'Not found' });
  const answer = body.answer || '';
  // evaluate answer: if OPENAI_KEY present, call OpenAI for feedback; else use simple evaluator
  let feedback = '';
  if(OPENAI_KEY){
    try{
      const prompt = `You are an interviewer evaluator. Score the answer and give concise feedback.\nQuestion: ${s.asked.slice(-1)[0].question}\nAnswer: ${answer}`;
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type':'application/json', 'Authorization': 'Bearer ' + OPENAI_KEY },
        body: JSON.stringify({ model: 'gpt-4o-mini', messages:[{role:'system', content:'You are an objective interviewer.'},{role:'user', content: prompt}], max_tokens: 400, temperature: 0.2 })
      });
      const j = await r.json();
      feedback = j.choices && j.choices[0] && j.choices[0].message ? j.choices[0].message.content : JSON.stringify(j);
    } catch(e){
      feedback = 'Error calling OpenAI: ' + e.message;
    }
  } else {
    // basic heuristic feedback
    const len = answer.split(' ').length;
    feedback = `Length: ${len} words. `;
    if(len < 20) feedback += 'Answer is too short — expand with specific examples and steps. ';
    if(answer.toLowerCase().includes('scale') || answer.toLowerCase().includes('database') || answer.toLowerCase().includes('api')) feedback += 'Good coverage of architecture topics. ';
    feedback += 'Use STAR for behavioral and include trade-offs for technical questions.';
  }
  // save answer and feedback
  s.answers = s.answers || [];
  s.answers.push({ answer, feedback, at: new Date().toISOString() });
  s.questionIndex = (s.questionIndex || 0) + 1;
  writeData(data);
  res.json({ feedback });
});

app.post('/api/sessions/:id/end', (req, res) => {
  const data = readData();
  const s = data.sessions.find(x=>x.id === req.params.id);
  if(!s) return res.status(404).json({ message: 'Not found' });
  s.status = 'ended'; s.ended_at = new Date().toISOString();
  writeData(data);
  res.json({ ok: true });
});

const PORT = process.env.PORT || 5173;
app.listen(PORT, ()=> console.log('Server running on', PORT));
