
Electron Desktop App Package - Interview Practice Platform
=========================================================

This package contains an Electron wrapper for the demo Interview Practice platform.
It includes the backend (server.js) and the static frontend (public/). Electron will launch the backend and open a desktop window pointing to http://localhost:5173.

How to run (developer machine + Node.js installed):
1. Unzip package.
2. In the project root run:
   npm install
3. Start the app in development:
   npm run start
   This will install dependencies (first time) and launch the Electron app. It starts the embedded server and opens the desktop window.
4. To create installers (Windows .exe, Mac .dmg, Linux AppImage):
   npm run dist
   (electron-builder will create artifacts in the 'dist' folder)

Important notes:
- Building installers requires additional platform-specific toolchains for macOS signing. For Windows builds from Windows or using CI is recommended.
- The backend uses a file 'sessions.json' for simple persistence. For production use, replace with a database.
- To enable OpenAI feedback, set environment variable OPENAI_API_KEY before starting the app (the server reads it).
- This is a demo; secure & productionize before sharing widely (add auth, HTTPS, packaged assets, etc.).

Demo video script & recording steps are included in DEMO_INSTRUCTIONS.md
